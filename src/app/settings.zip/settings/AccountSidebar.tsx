"use client";

import { useState, useEffect, useRef } from "react";
import { usePathname, useRouter } from "next/navigation";
import {
  User,
  Calendar,
  Gift,
  Pencil,
  HelpCircle,
  LogOut,
  ChevronDown,
} from "lucide-react";
import { useAppDispatch } from "../store/hook";
import { logoutUser } from "../store/slices/authSlice";
import { clearCart } from "../store/slices/cartSlice";

interface AccountSidebarProps {
  onNavigate?: (section: string) => void;
}

// We'll define the navigation links here to avoid repetition
const NAV_LINKS = [
  { id: "profile", label: "Profile", icon: User },
  { id: "appointments", label: "My Appointments", icon: Calendar },
  { id: "giftcards", label: "My Giftcards", icon: Gift },
  { id: "change-password", label: "Change Password", icon: Pencil },
];

const HELP_LINKS = [{ id: "faqs", label: "FAQs", icon: HelpCircle }];

export default function AccountSidebar({ onNavigate }: AccountSidebarProps) {
  const pathname = usePathname();
  const dispatch = useAppDispatch();
  const Router = useRouter();

  // State for managing the dropdown on mobile
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Handle navigation
  const handleNavigation = (section: string) => {
    if (onNavigate) {
      onNavigate(section);
    }
    setIsOpen(false); // Close dropdown on navigation
  };

  // Check if a path is active
  const isActive = (path: string) => {
    return pathname.endsWith(path);
  };

  // Find the currently active link to display in the dropdown trigger
  const activeLink = [...NAV_LINKS, ...HELP_LINKS].find((link) =>
    isActive(link.id)
  );

  // Handle logout
  const handleLogout = async () => {
    setIsOpen(false); // Close dropdown on logout
    try {
      await dispatch(logoutUser()).unwrap();
      dispatch(clearCart());
      Router.push("/");
    } catch (error) {
      console.error("❌ Logout error:", error);
    }
  };

  // Effect to close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Reusable component for the list of navigation items
  const NavigationList = () => (
    <nav className="p-2">
      <ul className="space-y-1">
        {NAV_LINKS.map((link) => {
          const active = isActive(link.id);
          return (
            <li key={link.id}>
              <button
                onClick={() => handleNavigation(link.id)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl transition-colors ${
                  active
                    ? "bg-green-500/20 text-green-400"
                    : "hover:bg-white/10"
                }`}>
                <link.icon
                  size={20}
                  className={active ? "text-green-400" : ""}
                />
                <span className={active ? "text-green-400" : ""}>
                  {link.label}
                </span>
              </button>
            </li>
          );
        })}
      </ul>

      <div className="border-t border-white/10 my-4"></div>

      <ul className="space-y-1">
        {HELP_LINKS.map((link) => {
          const active = isActive(link.id);
          return (
            <li key={link.id}>
              <button
                onClick={() => handleNavigation(link.id)}
                className={`w-full flex items-center gap-3 p-3 rounded-xl transition-colors ${
                  active
                    ? "bg-green-500/20 text-green-400"
                    : "hover:bg-white/10"
                }`}>
                <link.icon
                  size={20}
                  className={active ? "text-green-400" : ""}
                />
                <span className={active ? "text-green-400" : ""}>
                  {link.label}
                </span>
              </button>
            </li>
          );
        })}
        <li>
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-white/10 transition-colors">
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </li>
      </ul>
    </nav>
  );

  return (
    <div className="w-full">
      {/* --- SIDEBAR for large screens (lg and up) --- */}
      <div className="hidden lg:block bg-black text-white rounded-2xl border-2 border-white/10 overflow-hidden shadow-2xl">
        <div className="p-4 bg-black border-b border-white/10">
          <h2 className="text-xl font-bold">Account</h2>
        </div>
        <NavigationList />
      </div>

      {/* --- DROPDOWN for small screens (up to lg) --- */}
      <div ref={dropdownRef} className="relative lg:hidden">
        {/* Dropdown Trigger Button */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full flex items-center justify-between p-4 bg-black text-white rounded-2xl border-2 border-white/10 shadow-2xl">
          <div className="flex items-center gap-3">
            {activeLink ? (
              <activeLink.icon size={20} className="text-green-400" />
            ) : (
              <User size={20} />
            )}
            <span className="font-bold text-lg">
              {activeLink ? activeLink.label : "Account Menu"}
            </span>
          </div>
          <ChevronDown
            size={20}
            className={`transition-transform duration-300 ${
              isOpen ? "rotate-180" : ""
            }`}
          />
        </button>

        {/* Dropdown Panel */}
        <div
          className={`absolute top-full mt-2 w-full bg-black text-white rounded-2xl border-2 border-white/10 overflow-hidden shadow-2xl z-50 transition-all duration-300 ease-in-out ${
            isOpen
              ? "opacity-100 translate-y-0 pointer-events-auto"
              : "opacity-0 -translate-y-4 pointer-events-none"
          }`}>
          <NavigationList />
        </div>
      </div>
    </div>
  );
}
