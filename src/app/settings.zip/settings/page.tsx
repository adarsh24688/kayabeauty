"use client";

import { useState } from "react";
import AccountSidebar from "./AccountSidebar";
import ProfileSettings from "./profile/ProfileSettings";
import MyAppointments from "./appointments/page";
import ChangePasswordPage from "./change-password/ChangePassword";

export default function Page() {
  const [activeSection, setActiveSection] = useState("profile");

  // Handle navigation from sidebar
  const handleNavigation = (section: string) => {
    setActiveSection(section);
  };

  // Render the appropriate content based on active section
  const renderContent = () => {
    switch (activeSection) {
      case "profile":
        return <ProfileSettings />;
      case "appointments":
        return <MyAppointments />;
      case "giftcards":
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-white">My Giftcards</h2>
            <p className="text-gray-400 mt-2">
              Your giftcards will appear here.
            </p>
          </div>
        );
      case "change-password":
        return <ChangePasswordPage />;
      case "faqs":
        return (
          <div className="p-6">
            <h2 className="text-2xl font-bold text-white">FAQs</h2>
            <p className="text-gray-400 mt-2">
              Frequently asked questions and answers.
            </p>
          </div>
        );
      default:
        return <ProfileSettings />;
    }
  };

  return (
    <div className="min-h-screen bg-black text-white py-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header with gold gradient */}
        <div className="relative mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-center mb-2">
            Account Settings
          </h1>
          <div className="h-1 w-24 bg-gradient-to-r from-[#c59d5f] to-[#f4d03f] mx-auto rounded-full"></div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-1/4">
            <AccountSidebar onNavigate={handleNavigation} />
          </div>

          {/* Content Area */}
          {renderContent()}

          {/* <div className="lg:w-3/4 bg-black/80 backdrop-blur-xl border-2 border-white/10 rounded-2xl overflow-hidden shadow-2xl"> */}
          {/* </div> */}
        </div>
      </div>
    </div>
  );
}
